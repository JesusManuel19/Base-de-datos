<?php
require "../config/conexion.php";
$sql = "SELECT
id, nombre, documento, fecha_sys
FROM usuarios
WHERE 1";
foreach($dbh->query($sql) as $row)
{
    echo "Nombre=".$row[1]." - Documento= ".$row['documento']."<br>";
}
?>
