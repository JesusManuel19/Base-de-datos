<?php
require "../config/conexion.php";
$nombre = $_POST["nombre"];
$doc = $_POST["doc"];
$sql = "INSERT INTO usuarios
(nombre, documento, fecha_sys)
VALUES
('".$nombre."','".$doc."',now())";
if($dbh->query($sql))
{
echo "exito";
}else
{
echo "error";
}
?>
